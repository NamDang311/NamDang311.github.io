#!/bin/sh

#  stop_cache.sh
#  Sketch Cache Cleaner
#
#  Created by Sasha Prokhorenko on 2/6/17.
#  Copyright © 2017 Sasha Prokhorenko. All rights reserved.

# defaults write -app Sketch ApplePersistence -bool no
# exit 5
