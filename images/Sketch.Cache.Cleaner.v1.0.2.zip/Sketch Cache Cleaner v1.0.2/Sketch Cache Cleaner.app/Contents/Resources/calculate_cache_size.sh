#!/bin/sh

#  calculate_cache_size.sh
#  Sketch Cache Cleaner
#
#  Created by Sasha Prokhorenko on 2/6/17.
#  Copyright © 2017 Sasha Prokhorenko. All rights reserved.


du -sh /.DocumentRevisions-V100/

exit 5
